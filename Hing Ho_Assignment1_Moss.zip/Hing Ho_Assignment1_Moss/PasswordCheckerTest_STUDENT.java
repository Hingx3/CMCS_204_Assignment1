
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * STUDENT tests for the methods of PasswordChecker
 * @author 
 *
 */
public class PasswordCheckerTest_STUDENT {
	ArrayList<String> passwords;
	
	
	
	@Before
	public void setUp() throws Exception {
		String[] password = {"a1A#b1Bc1Cd1D", "334455BB##", "Im2cool4U#", "george2ZZZ#", "4Sale#",
		        "bertha22", "4wardMarch#", "august30", "a2cDe", "ApplesxxYYzz#", "aa11bb",
		        "pilotProject", "myPassword", "myPassword2", "myPassword2#"};
		    passwords = new ArrayList<String>();
		    passwords.addAll(Arrays.asList(password)); 
	}

	@After
	public void tearDown() throws Exception {
		passwords = null;
	}

	/**
	 * Test if the password is less than 6 characters long.
	 * This test should throw a LengthException for second case.
	 */
	@Test
	public void testIsValidPasswordTooShort()
	{
		try {
		      assertTrue(PasswordCheckerUtility.isValidPassword("HingHo1#"));
		      PasswordCheckerUtility.isValidPassword("ho3#");
		      assertTrue("Did not throw lengthException", false);
		    } catch (LengthException e) {
		      assertTrue("Successfully threw a lengthExcepetion", true);
		    } catch (Exception e) {
		      assertTrue("Threw some other exception besides lengthException", false);
		    }
		  
	}
	
	/**
	 * Test if the password has at least one uppercase alpha character
	 * This test should throw a NoUpperAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoUpperAlpha()
	{
		try {
		      assertTrue(PasswordCheckerUtility.isValidPassword("HingHo1#"));
		      PasswordCheckerUtility.isValidPassword("12345!#");
		      assertTrue("Did not throw NoUpperAlphaException", false);
		    } catch (NoUpperAlphaException e) {
		      assertTrue("Successfully threw a NoUpperAlphaExcepetion", true);
		    } catch (Exception e) {
		      assertTrue("Threw some other exception besides NoUpperAlphaException", false);
		    }
	}
	
	/**
	 * Test if the password has at least one lowercase alpha character
	 * This test should throw a NoLowerAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoLowerAlpha()
	{
		 try {
		      assertTrue(PasswordCheckerUtility.isValidPassword("HingHo1#"));
		      PasswordCheckerUtility.isValidPassword("HINGHO!1");
		      assertTrue("Did not throw NoLowerAlphaException", false);
		    } catch (NoLowerAlphaException e) {
		      assertTrue("Successfully threw a NoLowerAlphaExcepetion", true);
		    } catch (Exception e) {
		      assertTrue("Threw some other exception besides NoLowerAlphaException", false);
		    }
	}
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsWeakPassword()
	{
		 try {
		      assertEquals(true, PasswordCheckerUtility.isValidPassword("HingHo1#"));
		      boolean weakpassword = PasswordCheckerUtility.isWeakPassword​("Ho1#");
		      assertTrue(weakpassword);
		    } catch (Exception e) {
		      System.out.println(e.getMessage());
		      assertTrue("Threw some incorrect exception", true);
		    }
	}
	
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsValidPasswordInvalidSequence()
	{
		try {
		      assertEquals(true, PasswordCheckerUtility.isValidPassword("HingHo1#"));
		      PasswordCheckerUtility.isValidPassword("HingHooo1#");
		      assertTrue("Did not throw an InvalidSequenceException", false);
		    } catch (InvalidSequenceException e) {
		      assertTrue("Successfully threw an InvalidSequenceExcepetion", true);
		    } catch (Exception e) {
		      System.out.println(e.getMessage());
		      assertTrue("Threw some other exception besides an InvalidSequenceException", false);
		    }
	}
	
	/**
	 * Test if the password has at least one digit
	 * One test should throw a NoDigitException
	 */
	@Test
	public void testIsValidPasswordNoDigit()
	{
		 try {
		      assertEquals(true, PasswordCheckerUtility.isValidPassword("HingHo1#"));
		      PasswordCheckerUtility.isValidPassword("HingHooo");
		      assertTrue("Did not throw a NoDigitException", false);
		    } catch (NoDigitException e) {
		      assertTrue("Successfully threw a NoDigitException", true);
		    } catch (Exception e) {
		      System.out.println(e.getMessage());
		      assertTrue("Threw some other exception besides a NoDigitException", false);
		    }
	}
	
	/**
	 * Test correct passwords
	 * This test should not throw an exception
	 */
	@Test
	public void testIsValidPasswordSuccessful()
	{
		 try {
		      assertEquals(true, PasswordCheckerUtility.isValidPassword("HH3ingoo1!"));
		      assertEquals(true, PasswordCheckerUtility.isValidPassword("$Money100"));
		      assertEquals(true, PasswordCheckerUtility.isValidPassword("Sup@car63"));
		      assertEquals(true, PasswordCheckerUtility.isValidPassword("Bask!e1ball"));
		    } catch (Exception e) {
		      System.out.println(e.getMessage());
		      assertTrue("Threw some incorrect exception", false);
		    }
	}
	
	/**
	 * Test the invalidPasswords method
	 * Check the results of the ArrayList of Strings returned by the validPasswords method
	 */
	@Test
	public void testInvalidPasswords() {
		 ArrayList<String> password;
		 password = PasswordCheckerUtility.getInvalidPasswords​(passwords);

		    Scanner input = new Scanner(password.get(0)); 
		    assertEquals(input.next(), "334455BB##");
		    String nextResults = input.nextLine().toLowerCase();
		    assertTrue(nextResults.contains("lowercase"));

		    input = new Scanner(password.get(1)); 
		    assertEquals(input.next(), "george2ZZZ#");
		    nextResults = input.nextLine().toLowerCase();
		    assertTrue(nextResults.contains("same"));

		    input = new Scanner(password.get(2)); 
		    assertEquals(input.next(), "4Sale#");
		    nextResults = input.nextLine().toLowerCase();
		    assertTrue(nextResults.contains("long"));

		    input = new Scanner(password.get(3)); 
		    assertEquals(input.next(), "bertha22");
		    nextResults = input.nextLine().toLowerCase();
		    assertTrue(nextResults.contains("uppercase"));

		    input = new Scanner(password.get(4)); 
		    assertEquals(input.next(), "august30");
		    nextResults = input.nextLine().toLowerCase();
		    assertTrue(nextResults.contains("uppercase"));

		    input = new Scanner(password.get(5)); 
		    assertEquals(input.next(), "a2cDe");
		    nextResults = input.nextLine().toLowerCase();
		    assertTrue(nextResults.contains("long"));
		    
		    input = new Scanner(password.get(6)); 
		    assertEquals(input.next(), "ApplesxxYYzz#");
		    nextResults = input.nextLine().toLowerCase();
		    assertTrue(nextResults.contains("digit"));
		    
		    
		    
		    
		    
		    
		  }
	}
	

