import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * 
 * @author hohin
 *
 */
public class PasswordCheckerUtility extends java.lang.Object{
	/**
	 * 
	 * @param password 
	 * @return- Return true if an valid password, return false if an invalid password
	 * @throws LengthException - if length is less than 6 characters
	 * @throws NoUpperAlphaException - if no uppercase alphabetic
	 * @throws NoLowerAlphaException - if no lowercase alphabetic
	 * @throws NoDigitException - if no digit
	 * @throws NoSpecialCharacterException - if no special character
	 * @throws InvalidSequenceException - if more than 2 of same character
	 */
	public static boolean isValidPassword(java.lang.String password) throws LengthException, NoUpperAlphaException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException{
		;
		if (isValidLength​(password) &&  hasUpperAlpha​(password) && hasLowerAlpha​(password) && 
				hasDigit​(password) &&  hasSpecialChar​(password) &&  NoSameCharInSequence​(password)) {
			return true;
		}
		else {
			return false;
		}
		
		
	}
	
	/**
	 * 
	 * @param password
	 * @param passwordConfirm
	 */
	public static void comparePasswords​(java.lang.String password, java.lang.String passwordConfirm) {
		
	}
	
	/**
	 * 
	 * @param password
	 * @param passwordConfirm
	 * @return - Return true if password equals to passwordConfirm and return false if not
	 * @throws UnmatchedException
	 */
	public static boolean comparePasswordsWithReturn​(java.lang.String password, java.lang.String passwordConfirm) {
		if (password.equals(passwordConfirm)) {
		return true;
		}
		else {
			return false;
		}
	}
	
	
	/**
	 * 
	 * @param password
	 * @return - Returns true if the password length is greater or equal than 6 and throw LengthException if not
	 * @throws LengthException
	 */
	public static boolean isValidLength​(java.lang.String password) throws LengthException{
		if (password.length() <= 6) {
			throw new LengthException();
		}
		else {
			return true;
		}
	}
	
	/**
	 * 
	 * @param password
	 * @return - Return true if password has at least one uppercase character and throws NoUpperAlphaException if not
	 * @throws NoUpperAlphaException
	 */
	public static boolean hasUpperAlpha​(java.lang.String password) throws NoUpperAlphaException{
		for (Character character : password.toCharArray()) {
		      if (Character.isUpperCase(character)) {
		        return true;
		      }
		    }
		    throw new NoUpperAlphaException();
		
	}
	
	/**
	 * 
	 * @param password
	 * @return - Returns true if password has a lowercase character and throws NoLowerAlphaException if not.
	 * @throws NoLowerAlphaException
	 */
	public static boolean hasLowerAlpha​(java.lang.String password) throws NoLowerAlphaException{
		for (Character character : password.toCharArray()) {
		      if (Character.isLowerCase(character)) {
		        return true;
		      }
		    }
		    throw new NoLowerAlphaException();
		
	}
	
	/**
	 * 
	 * @param password
	 * @return - Return true if password contains at least one digit and throws NoDigitException if not
	 * @throws NoDigitException
	 */
	public static boolean hasDigit​(java.lang.String password) throws NoDigitException{
		for (Character character : password.toCharArray()) {
		      if (Character.isDigit(character)) {
		        return true;
		      }
		    }
		    throw new NoDigitException();
	}
	
	/**
	 * 
	 * @param password
	 * @return - Return true if password has at least one special character and throws NoSpecialCharacterException if not
	 * @throws NoSpecialCharacterException
	 */
	public static boolean hasSpecialChar​(java.lang.String password) throws NoSpecialCharacterException{
		 Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");
		    Matcher matcher = pattern.matcher(password);
		    if (!matcher.find()) {
		    	 throw new NoSpecialCharacterException();
		    }
		    return true;
		    
		
	}
	
	/**
	 * 
	 * @param password
	 * @return - Return true if password characters do not repeat more than 2 times and throw InvalidSequenceException if not
	 * @throws InvalidSequenceException
	 */
	public static boolean NoSameCharInSequence​(java.lang.String password) throws InvalidSequenceException{
		for (int i = 0; i < password.length() - 2; i++) {
		      if (password.charAt(i) == password.charAt(i + 1)) {
		        if (password.charAt(i + 1) == password.charAt(i + 2)) {
		          throw new InvalidSequenceException();
		        }
		      }
		    }
		    return true;
		  }
	
	/**
	 * 
	 * @param password
	 * @return - Return true if length of password is greater than or equal to 6 but less than or equal to 9 and throw WeakPasswordException if not
	 * @throws WeakPasswordException
	 */
	public static boolean isWeakPassword​(java.lang.String password) throws WeakPasswordException{
		if (password.length() < 10) {
			throw new WeakPasswordException();
		}
		else {
			return false;
		}
	}
	
	
	
	
	/**
	 * 
	 * @param password
	 * @return - Returns an arraylist of invalid passwords
	 */
	public static java.util.ArrayList<java.lang.String> getInvalidPasswords​(java.util.ArrayList<java.lang.String> password){
		
		
		ArrayList<String> invalid = new ArrayList<>();
		
		
		for(int i = 0; i < password.size(); i++) {
			try{
				isValidPassword(password.get(i));
			}catch(Exception exception) {
				invalid.add(password.get(i) + " " + exception.getMessage());
			}
		}
		return invalid;
		
		
		
		
		
		
		
	}

	

	
}