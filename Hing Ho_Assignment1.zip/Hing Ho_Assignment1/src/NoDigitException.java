/**
 * If the password doesn't contain a numeric character
 * @author hohin
 *
 */
public class NoDigitException extends Exception {
	public NoDigitException() {
		super("The password must contain at least one digit");
	}
}
