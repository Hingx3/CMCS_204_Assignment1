/**
 * If the length of password is less than 6 characters.
 * @author hohin
 *
 */
public class LengthException extends Exception {
	public LengthException() {
		super("The password must be at least 6 characters long");
	}
}
