/**
 * If password and re-typed password inputs are not identical
 * @author hohin
 *
 */
public class UnmatchedException extends Exception {
	public UnmatchedException() {
		super("The passwords do not match");
	}
}
